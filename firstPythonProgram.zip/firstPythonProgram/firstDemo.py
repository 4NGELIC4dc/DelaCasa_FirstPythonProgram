username=input("Enter username:")
username
print(username)

age=input("Enter age:")
age
print(age)

first=int(input("Enter the first number:"))
second=int(input("Enter the second number:"))
print("The username is", username ,"and the age is", age)
print("The product is", first*second)